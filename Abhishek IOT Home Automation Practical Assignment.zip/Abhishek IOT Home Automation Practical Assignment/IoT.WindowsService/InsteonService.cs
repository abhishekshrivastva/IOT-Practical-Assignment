﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using Microsoft.AspNet.SignalR.Client;
using SoapBox.FluentDwelling;
using Topshelf;

namespace IoT.WindowsService
{
    public class InsteonService : ServiceControl
    {
        private static string ServiceUri;
        private static Connection connection;

        //Insteon related
        private static Plm plm = new Plm("COM4");

        public bool Start(HostControl hostControl)
        {
            ServiceUri = ConfigurationManager.AppSettings["ServiceUri"];

            connection = new Connection(ServiceUri, "name=Client");
            connection.Received += connection_Received;
            connection.StateChanged += connection_StateChanged;
            Console.WriteLine("Connecting...");
            connection.Start().Wait();
            string inputMsg;
            while (!string.IsNullOrEmpty(inputMsg = Console.ReadLine()))
            {
                connection.Send(inputMsg).Wait();
            }
            connection.Stop();

            return true;
        }

        static void connection_StateChanged(StateChange state)
        {
            if (state.NewState == ConnectionState.Connected)
            {
                Console.WriteLine("Connected.");
            }
        }
        static void connection_Received(string data)
        {
            //Parse the commands
            //Format: 
            //Name,Command,DeviceName(optional),Port(optional)
            string[] command = data.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            if (command.Length > 0)
                if (command[0].Equals("Server", StringComparison.InvariantCultureIgnoreCase))
                {
                    string commandName = command[1].ToLower();
                    if (command.Length > 2)
                    {
                        string deviceid = command[2];
                        switch (commandName)
                        {
                            case "turnoff":
                                {
                                    plm.Network.X10
                                            .House("A")
                                            .Unit(2)
                                            .Command(X10Command.Off);
                                }
                                break;
                            case "turnon":
                                {
                                    plm.Network.X10
                                            .House("A")
                                            .Unit(2)
                                            .Command(X10Command.On);
                                }
                                break;
                        }
                    }
                    else
                    {
                        switch (commandName)
                        {
                            case "getlist"://not tested
                                {
                                    var database = plm.GetAllLinkDatabase();
                                    string devices = "";
                                    if (!plm.Error)
                                    {
                                        foreach (var record in database.Records)
                                        {
                                            devices += record.DeviceId.ToString();
                                        }
                                    }
                                    else
                                    {
                                        devices += "Error";
                                    }

                                    connection.Send(devices).Wait();
                                }
                                break;
                        }
                    }
                }
        }

        public bool Stop(HostControl hostControl)
        {
            if (connection.State == ConnectionState.Connected)
                connection.Stop();
            return true;
        }
    }
}
