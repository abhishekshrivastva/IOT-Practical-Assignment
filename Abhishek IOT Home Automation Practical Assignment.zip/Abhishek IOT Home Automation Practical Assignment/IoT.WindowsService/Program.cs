﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Topshelf;
using Topshelf.HostConfigurators;
using Topshelf.ServiceConfigurators;

namespace IoT.WindowsService
{
    class Program
    {
        static void Main(string[] args)
        {
            var host = HostFactory.New(ConfigureHost);
            host.Run();
        }

        private static void ConfigureHost(HostConfigurator x)
        {
            x.Service<InsteonService>(ConfigureService);
            x.SetDisplayName("Insteon Service");
            x.SetDescription("Insteon Controller Service");
            x.SetInstanceName("Insteon");
            x.SetServiceName("Insteon");
            x.StartAutomatically();
            x.RunAsPrompt();
        }

        private static void ConfigureService(ServiceConfigurator<InsteonService> sc)
        {
            sc.ConstructUsing(() => new InsteonService());

            // the start and stop methods for the service
            sc.WhenStarted((s, hostControl) => s.Start(hostControl));
            sc.WhenStopped((s, hostControl) => s.Stop(hostControl));
        }
    }
}
